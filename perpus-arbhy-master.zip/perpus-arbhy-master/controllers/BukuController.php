<?php

namespace app\controllers;

use Yii;
use app\models\Buku;
use app\models\PencariBuku;
use yii2tech\spreadsheet\Spreadsheet;
use yii\data\ActiveDataProvider;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\UploadedFile;

/**
 * BukuController implements the CRUD actions for Buku model.
 */
class BukuController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Buku models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new PencariBuku();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Buku model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    public function actionExport()
    {
        $exporter = new Spreadsheet([
            'dataProvider' => new ActiveDataProvider([
                'query' => Buku::find(),
            ]),
        ]);
        return $exporter->send('daftar_buku.xls');
    }

    /**
     * Creates a new Buku model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate($id_penulis = null, $id_kategori = null, $id_penerbit = null)
    {
        $model = new Buku();
        $model->id_penulis = $id_penulis;
        $model->id_kategori = $id_kategori;
        $model->id_penerbit = $id_penerbit;
        if ($model->load(Yii::$app->request->post())) {
            $img = UploadedFile::getInstance($model, 'sampul');
            $model->sampul = $model->nama.'.'.$img->extension;
            $img->saveAs(Yii::$app->basePath.'/web/uploads/'.$model->sampul);
            $model->save();
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Buku model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        $sampulLama = $model->sampul;
        if ($model->load(Yii::$app->request->post())) {
            $img = UploadedFile::getInstance($model, 'sampul');
            if($img != '') {
                $model->sampul = $model->nama.'.'.$img->extension;
            } else {
                $model->sampul = $sampulLama;
            }

            if($model->save()) {
                if($img != '') {
                    if(file_exists(Yii::$app->basePath.'/web/uploads/'.$sampulLama) AND $model->sampul != null) {
                        unlink(Yii::$app->basePath.'/web/uploads/'.$sampulLama);
                    }
                    $img->saveAs(Yii::$app->basePath.'/web/uploads/'.$model->sampul);
                }
            }
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Buku model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $model = $this->findModel($id);
        unlink(Yii::$app->basePath.'/web/uploads/'.$model->sampul);
        $model->delete();
        return $this->redirect(['index']);
    }

    /**
     * Finds the Buku model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Buku the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Buku::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
