<?php

namespace app\models;

use Yii;
use yii\helpers\ArrayHelper;
/**
 * This is the model class for table "kategori".
 *
 * @property int $id_kategori
 * @property string $nama
 */
class Kategori extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'kategori';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nama'], 'required'],
            [['nama'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_kategori' => 'Id Kategori',
            'nama' => 'Nama',
        ];
    }

    public function getBuku()
    {
        return Buku::find()->where(['id_kategori' => $this->id_kategori])->all();
    }

    public static function getList()
    {
        return ArrayHelper::map(self::find()->all(), 'id_kategori', 'nama');
    }

    public function getKategoriCount()
    {
        return static::find()->count();
    }

    public static function getGrafikList()
    {
        $data = [];
        foreach (static::find()->all() as $kategori) {
            $data[] = [$kategori->nama, (int) $kategori->getManyBuku()->count()];
        }
        return $data;
    }

    public function getManyBuku() 
    {
        return $this->hasMany(Buku::class, ['id_kategori' => 'id_kategori']);
    }
}
