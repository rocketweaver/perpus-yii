<?php

namespace app\models;

use Yii;
use yii\helpers\ArrayHelper;
use yii\web\UploadedFile;
use app\models\Penulis;
use app\models\Penerbit;
/**
 * This is the model class for table "buku".
 *
 * @property int $id
 * @property string $nama
 * @property string|null $tahun_terbit
 * @property int|null $id_penulis
 * @property int|null $id_penerbit
 * @property int|null $id_kategori
 * @property string|null $sinopsis
 * @property string|null $sampul
 * @property string|null $berkas
 */
class Buku extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'buku';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nama'], 'required'],
            [['tahun_terbit'], 'safe'],
            [['id_penulis', 'id_penerbit', 'id_kategori'], 'integer'],
            [['sinopsis'], 'string'],
            [['sampul'], 'file', 'extensions' => 'jpeg, jpg, png'],
            [['nama', 'berkas', 'sampul'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'nama' => 'Nama',
            'tahun_terbit' => 'Tahun Terbit',
            'id_penulis' => 'Penulis',
            'id_penerbit' => 'Penerbit',
            'id_kategori' => 'Kategori',
            'sinopsis' => 'Sinopsis',
            'file' => 'Sampul',
            'berkas' => 'Berkas',
        ];
    }

    public function getPenulis()
    {
        return $this->hasOne(Penulis::className(), ['id' => 'id_penulis']);
    }

    public function getPenerbit()
    {
        return $this->hasOne(Penerbit::className(), ['id' => 'id_penerbit']);
    }

    public function getKategori()
    {
        return $this->hasOne(Kategori::className(), ['id_kategori' => 'id_kategori']);
    }

    public static function getList()
    {
        return ArrayHelper::map(self::find()->all(), 'id', 'nama');
    }

    public function getBukuCount()
    {
        return static::find()->count();
    }
}
