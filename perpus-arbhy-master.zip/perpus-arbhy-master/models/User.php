<?php

namespace app\models;

use Yii;
use yii\helpers\ArrayHelper;
use app\models\Anggota;
use app\models\Petugas;
/**
 * This is the model class for table "user".
 *
 * @property int $id
 * @property string $username
 * @property string $password
 * @property int|null $id_anggota
 * @property int|null $id_petugas
 * @property int|null $id_user_role
 * @property int|null $status
 */
class User extends \yii\db\ActiveRecord implements \yii\web\IdentityInterface
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'user';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['username', 'password'], 'required'],
            [['id_anggota', 'id_petugas', 'id_user_role', 'status'], 'integer'],
            [['username'], 'string', 'max' => 255],
            [['password'], 'string', 'max' => 25],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'username' => 'Username',
            'password' => 'Password',
            'id_anggota' => 'Anggota',
            'id_petugas' => 'Petugas',
            'id_user_role' => 'User Role',
            'status' => 'Status',
        ];
    }

    /**
     * @inheritdoc
     */
    public static function findIdentity($id)
    {
        return static::findOne($id);
    }

     /**
     * {@inheritdoc}
     */
    public static function findIdentityByAccessToken($token, $type = null)
    {
        return self::find()->where(['access_token' => $token])->one();
    }

    /**
     * @inheritdoc
     */
    public function getId()
    {
        return $this->id;
    }

     /**
     * Finds user by username
     *
     * @param string $username
     * @return static|null
     */
    public static function findByUsername($username)
    {
        return self::findOne(['username' => $username]);
    }

    /**
     * {@inheritdoc}
     */
    public function getAuthKey()
    {
        return $this->auth_key;
    }

    /**
     * {@inheritdoc}
     */
    public function validateAuthKey($authKey)
    {
        return $this->auth_key === $authKey;
    }


    public function validatePassword($password)
    {
        return $this->password === $password;
    }

    public function getAnggota() 
    {
        return $this->hasOne(Anggota::className(), ['id' => 'id_anggota']);
    }

    public function getPetugas() 
    {
        return $this->hasOne(Petugas::className(), ['id' => 'id_petugas']);
    }

    public function getUserRole() 
    {
        return $this->hasOne(UserRole::className(), ['id' => 'id_user_role']);
    }

    public function getStatus()
    {
        return ['1' => 'Aktif', '0' => 'Tidak aktif'];
    }

    public static function isAdmin()
    {
        if (Yii::$app->user->isGuest){
            return false;
        }

        $model = User::findOne(['username' => Yii::$app->user->identity->username]);

        if ($model == null){
            return false;
        }

        elseif ($model->id_user_role == 1) {
            return true;
        }
        return false;
    }


    public static function isAnggota()
    {
        if (Yii::$app->user->isGuest){
            return false;
        }

        $model = User::findOne(['username' => Yii::$app->user->identity->username]);

        if ($model == null){
            return false;
        }

        elseif ($model->id_user_role == 2) {
            return true;
        }
        return false;
    }


    public static function isPetugas()
    {
        if (Yii::$app->user->isGuest){
            return false;
        }

        $model = User::findOne(['username' => Yii::$app->user->identity->username]);

        if ($model == null){
            return false;
        }

        elseif ($model->id_user_role == 3) {
            return true;
        }
        return false;
    }
}
