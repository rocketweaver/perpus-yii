<?php

namespace app\models;

use Yii;
use yii\helpers\ArrayHelper;
/**
 * This is the model class for table "anggota".
 *
 * @property int $id
 * @property string $nama
 * @property string|null $alamat
 * @property string|null $telepon
 * @property string|null $email
 * @property int|null $status_aktif
 */
class Anggota extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'anggota';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nama'], 'required'],
            [['status_aktif'], 'integer'],
            [['nama', 'alamat'], 'string', 'max' => 255],
            [['telepon', 'email'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'nama' => 'Nama',
            'alamat' => 'Alamat',
            'telepon' => 'Telepon',
            'email' => 'Email',
            // 'status_aktif' => 'Status Aktif',
        ];
    }

    public function getStatus()
    {
        if($this->status_aktif == 1) {
            return "Aktif";
        } else {
            return "Mati";
        }
    }

    public function getList()
    {
        return ArrayHelper::map(self::find()->all(), 'id', 'nama');
    }

    public function getAnggotaCount()
    {
        return static::find()->count();
    }
}
