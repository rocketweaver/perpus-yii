<?php

use yii\helpers\Html;
use yii\grid\GridView;
use app\models\Buku;
use app\models\Anggota;
/* @var $this yii\web\View */
/* @var $searchModel app\models\PencariPeminjaman */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Peminjaman';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="peminjaman-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Peminjaman', ['create'], ['class' => 'btn btn-success']) ?>
        <?= Html::a('Export Data', ['export'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>
    <div class="box box-default">
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'summary' => '',
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            [
                'attribute' => 'id_buku',
                'filter' => Buku::getList(),
                'value' => 'buku.nama'
            ],
            [
                'attribute' => 'id_anggota',
                'filter' => Anggota::getList(),
                'value' => function($data) {
                    return $data->anggota->nama;
                }
            ],
            'tanggal_pinjam',
            'tanggal_kembali',
            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    </div>

</div>
