<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Kategori */

$this->title = 'Detail';
$this->params['breadcrumbs'][] = ['label' => 'Kategori', 'url' => ['index']];
$this->params['breadcrumbs'][] = $model->id_kategori;
\yii\web\YiiAsset::register($this);
?>
<div class="kategori-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id_kategori], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id_kategori], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'nama',
        ],
    ]) ?>
    <p>
        <?= Html::a('Create Buku', ['/buku/create', 'id_kategori' => $model->id], ['class' => 'btn btn-success']) ?>
    </p>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>Daftar Buku</th>
        </tr>
        </thead>
        <?php foreach($model->buku as $list) : ?>
        <tbody>
        <tr>
            <td><?= $list['nama']?></td>
        </tr>
        </tbody>
        <?php endforeach?>
    </table>
</div>
