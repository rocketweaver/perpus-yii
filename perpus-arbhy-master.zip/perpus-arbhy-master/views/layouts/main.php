<?php

/* @var $this \yii\web\View */
/* @var $content string */

use app\widgets\Alert;
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $this->registerCsrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body>

<div class="wrap">
    <?php
    if(Yii::$app->user->isGuest) {
        NavBar::begin([
            'brandLabel' => 'Perpustakaan',
            'brandUrl' => Yii::$app->homeUrl,
            'options' => [
                'class' => 'navbar-inverse navbar-fixed-top',
            ],
        ]);
        echo Nav::widget([
            'options' => ['class' => 'navbar-nav navbar-right'],
            'items' => [
                ['label' => 'Home', 'style' => 'font-weight: bold', 'url' => ['/site/index']],
                ['label' => 'Login', 'url' => ['/site/login']],
                ['label' => 'Admin', 'url' => ['/admin/login']],
            ]
        ]);
        NavBar::end();
    } else {
        NavBar::begin([
            'brandLabel' => 'Perpustakaan',
            'brandUrl' => Yii::$app->homeUrl,
            'options' => [
                'class' => 'navbar-inverse navbar-fixed-top',
            ],
        ]);
        echo Nav::widget([
            'options' => ['class' => 'navbar-nav navbar-right'],
            'items' => [
                ['label' => 'Home', 'url' => ['/site/index']],
                ['label' => 'Anggota', 'url' => ['/anggota/index']],
                ['label' => 'Peminjaman', 'url' => ['/peminjaman/index']],
                [
                    'label' => 'Detail Buku', 
                    'url' => '#',
                    'items' => [
                        ['label' => 'Buku', 'icon' => 'home', 'url' => ['/buku/index']],
                        ['label' => 'Kategori', 'url' => ['/kategori/index']],
                        ['label' => 'Penerbit', 'url' => ['/penerbit/index']],
                        ['label' => 'Penulis', 'url' => ['/penulis/index']],
                    ]
                ],
                [
                    'label' => 'Detail User',
                    'url' => '#',
                    'items' => [
                        ['label' => 'Petugas', 'url' => ['/petugas/index']],
                        ['label' => 'User', 'url' => ['/user/index']],
                        ['label' => 'User Role', 'url' => ['/user-role/index']],
                    ]
                ],
                '<li>'
                . Html::beginForm(['/site/logout'], 'post')
                . Html::submitButton(
                    'Logout (' . Yii::$app->user->identity->username . ')',
                    ['class' => 'btn btn-link logout']
                )
                . Html::endForm()
                . '</li>'
            ]
        ]);
        NavBar::end();
    }
    ?>

    <div class="container">
        <?= Breadcrumbs::widget([
            'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
        ]) ?>
        <?= Alert::widget() ?>
        <?= $content ?>
    </div>
</div>

<footer class="footer" style="background: #222222; color: white">
    <div class="container">
        <p class="pull-left">&copy; My Company <?= date('Y') ?></p>

        <p class="pull-right"><?= Yii::powered() ?></p>
    </div>
</footer>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
