<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Buku */

$this->title = 'Menambah Buku';
$this->params['breadcrumbs'][] = ['label' => 'Buku', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="buku-create">

    <h1><?= Html::encode($this->title) ?></h1>
    
    <?php
    if(isset($id)){
        echo $this->render('_form', [
            'model' => $model,
            'id' => $id
        ]);
    } else {
        echo $this->render('_form', [
            'model' => $model,
        ]); 
    }
    
    ?>

</div>
