<?php
use yii\helpers\Html;
use yii\helpers\Url;
use app\models\Buku;
use app\models\Anggota;
use app\models\Penulis;
use app\models\Penerbit;
use app\models\Kategori;
use app\models\Peminjaman;
use app\models\Petugas;
use app\models\User;
use app\components\Helper;
use yiier\chartjs\ChartJs;
use miloschuman\highcharts\Highcharts;

$this->title = 'Halaman Dashboard';
?>

<?php if (User::isAdmin() || User::isPetugas()) : ?>
      
<div class="body-content">

<div class="row">
   <div class="col-lg-3 col-xs-6">
   <!-- small box -->
   <div class="small-box bg-aqua">
         <div class="inner">
            <div class="icon"><i class="fa fa-group"></i></div>
               <h3><div class="count"><?= Yii::$app->formatter->asInteger(Anggota::getAnggotaCount()); ?></div></h3>
               <h4>Anggota</h4>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="<?=Url::to(['anggota/index'])?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
   </div>

        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
        <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <div class="icon"><i class="fa fa-book"></i></div>
              <h3><div class="count"><?= Yii::$app->formatter->asInteger(Buku::getBukuCount()); ?></div></h3>
              <h4>Buku</h4>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="<?=Url::to(['buku/index'])?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <div class="icon"><i class="fa fa-user"></i></div>
              <h3><div class="count"><?= Yii::$app->formatter->asInteger(Penulis::getPenulisCount()); ?></div></h3>
              <h4>Penulis</h4>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="<?=Url::to(['penulis/index'])?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>


        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-purple">
            <div class="inner">
              <div class="icon"><i class="fa fa-building"></i></div>
              <h3><div class="count"><?= Yii::$app->formatter->asInteger(Penerbit::getPenerbitCount()); ?></div></h3>
              <h4>Penerbit</h4>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="<?=Url::to(['penerbit/index'])?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        

        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <div class="icon"><i class="fa fa-briefcase"></i></div>
              <h3><div class="count"><?= Yii::$app->formatter->asInteger(Peminjaman::getPeminjamanCount()); ?></div></h3>
              <h4>Peminjaman</h4>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="<?=Url::to(['peminjaman/index'])?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>


        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-orange">
            <div class="inner">
              <div class="icon"><i class="fa fa-tasks"></i></div>
              <h3><div class="count"><?= Yii::$app->formatter->asInteger(Kategori::getKategoriCount()); ?></div></h3>
              <h4>Kategori</h4>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="<?=Url::to(['kategori/index'])?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

         <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-blue">
            <div class="inner">
              <div class="icon"><i class="fa fa-user"></i></div>
              <h3><div class="count"><?= Yii::$app->formatter->asInteger(Petugas::getPetugasCount()); ?></div></h3>
              <h4>Petugas</h4>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="<?=Url::to(['anggota/index'])?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

<div class="col-sm-6">
  <div class="box-body">
    <?=Highcharts::widget([
        'options' => [
            'credits' => false,
            'title' => ['text' => 'Buku Berdasarkan Kategori'],
            'exporting' => ['enabled' => true],
            'plotOptions' => [
              'bar' => [
                          'cursor' => 'pointer',
                      ],
              ],
              'series' => [
                            [
                              'type' => 'pie',
                              'name' => 'buku',
                              'data' => Kategori::getGrafikList(),
                            ],
                        ],
          ],
    ]);?>
  </div>
</div>
<div class="col-sm-6">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Buku Berdasarkan Penulis</h3>
            </div>
            <div class="box-body">
                <?=Highcharts::widget([
                    'options' => [
                        'credits' => false,
                        'title' => ['text' => 'Penulis Buku'],
                        'exporting' => ['enabled' => true],
                        'xAxis' => [
                            'categories' => Penulis::getNama(),
                        ],
                        'plotOptions' => [
                            'pie' => [
                                'cursor' => 'pointer',
                            ],
                        ],
                        'series' => [
                            [
                                'type' => 'bar',
                                'name' => 'Buku',
                                'data' => Penulis::getGrafikList(),
                            ],
                        ],
                    ],
                ]);?>
            </div>
  </div>
</div>

<div class="col-sm-6">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Buku Berdasarkan Penerbit</h3>
            </div>
            <div class="box-body">
                <?=Highcharts::widget([
                    'options' => [
                        'credits' => false,
                        'title' => ['text' => 'Penerbit Buku'],
                        'exporting' => ['enabled' => true],
                        'xAxis' => [
                            'categories' => Penerbit::getNama(),
                        ],
                        'plotOptions' => [
                            'pie' => [
                                'cursor' => 'pointer',
                            ],
                        ],
                        'series' => [
                            [
                                'type' => 'column',
                                'name' => 'Buku',
                                'data' => Penerbit::getGrafikList(),
                            ],
                        ],
                    ],
                ]);?>
            </div>
        </div>
    </div>

    <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="x_panel">
                    <h3 class="box-title">Grafik Peminjaman Buku</h3>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                     
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">


                    <!-- <canvas id="mybarChart"> -->
                        <div class="box-body">
                  <?= ChartJs::widget([
                'type' => 'bar',
                'options' => [
                    'height' => 600,
                    'width' => 900,
                    'color' => 'red'
                ],
                'data' => [
                    'labels' => Helper::getListBulan(),
                     'datasets' => [
                         [
                             'label'=> 'Peminjaman',
                             'data' => Peminjaman::getGrafikPeminjamanByBulan()
                         ],
                     ]
                ]
            ]);?>
                         
        </div> 
<?php endif ?>

<?php if (User::isAnggota()) : ?>

<div class="row">
<?php foreach (Buku::find()->all() as $buku) :?> 
    <!-- Kolom box mulai -->
    <div class="col-md-4">

        <!-- Box mulai -->
        <div class="box box-widget">

            <div class="box-header with-border">
                <div class="user-block">
                    <span class="username"><?= Html::a($buku->nama, ['buku/view', 'id' => $buku->id]); ?></span>
                    <span class="description"> Di Terbitkan : Tahun <?= $buku->tahun_terbit; ?></span>
                </div>
                <div class="box-tools">
                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                </div>
            </div>

            <div class="box-body">
                <center>
                    <?php if ($buku->sampul != '') { ?>
                        <img style="height: 300px" class="img-responsive pad" src="<?= Yii::$app->request->baseUrl.'/uploads/'.$buku['sampul']; ?>" alt="Photo">
                    <?php } else { ?>
                        <img style="height: 300px" class="img-responsive pad" src="<?= Yii::$app->request->baseUrl.'/upload/no-images.png' ?>" alt="Photo">
                    <?php } ?>
                    
                </center>
                <p>Sinopsis : <?= substr($buku->sinopsis,0,120);?> ...</p>
                <?= Html::a("<i class='fa fa-eye'> Detail Buku</i>",["buku/view","id"=>$buku->id],['class' => 'btn btn-default']) ?>
                <?= Html::a('<i class="fa fa-file"> Pinjam Buku</i>', ['peminjaman/create', 'id_buku' => $buku->id], ['class' => 'btn btn-primary',
                    'data' => [
                        'confirm' => 'Apa anda yakin ingin meminjam buku ini?',
                    ],
                ]) ?>
                <!-- <span class="pull-right text-muted">127 Peminjam - 3 Komentar</span> -->
            </div>

        </div>
        <!-- Box selesai -->

    </div>
    <!-- Kolom box selesai -->  
<?php
    endforeach
?>
</div>


<?php endif ?>