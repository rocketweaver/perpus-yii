<?php

return [
    //!!!!!!
    //Databasenya ada di folder db.sql
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=perpus_sinjam',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',

    // Schema cache options (for production environment)
    //'enableSchemaCache' => true,
    //'schemaCacheDuration' => 60,
    //'schemaCache' => 'cache',
];
